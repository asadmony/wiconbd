@extends('layouts.adminlayout')

@section('content')
<h1 class="mt-5">Dashboard</h1>
<ol class="breadcrumb mb-4">
    <li class="breadcrumb-item">Dashboard</li>
</ol>
<div class="container">
    <div class="card p-3">
        <h2>Welcome to admin panel.</h2>
    </div>
</div>
@endsection
