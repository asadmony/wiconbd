
<?php $__env->startSection('content'); ?>
    <h1 class="mt-4">Auto Code Generator</h1>
                        <ol class="breadcrumb mb-4">
                            <li class="breadcrumb-item">Auto codes</li>
                        </ol>
<div class="container">
        <div class="header">
            <h2>List of codes</h2>
            <hr>
        </div>
        <div class="" style="">
             <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.alert','data' => []]); ?>
<?php $component->withName('alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
            <div class="col-xs-10">
                <div class="table-responsive">
                    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                        <thead>
                            <tr>
                                <th>Auto Code For</th>
                                <th>Prefix</th>
                                <th>Year</th>
                                <th>Suffix</th>
                                <th>Example</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tfoot>
                            <tr>
                                <th>Auto Code For</th>
                                <th>Prefix</th>
                                <th>Year</th>
                                <th>Suffix</th>
                                <th>Example</th>
                                <th>Action</th>
                            </tr>
                        </tfoot>
                        <tbody>
                            <?php $__currentLoopData = $autos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $auto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <th><?php echo e($auto->autocodekey); ?></th>
                                <td><?php echo e($auto->prefix); ?></td>
                                <td><?php echo e(date("Y")); ?></td>
                                <td><?php echo e($auto->suffix); ?></td>
                                <td>Code will be like : <?php echo e($auto->prefix.date("Y").$auto->suffix); ?></td>
                                <td>
                                    <a class="btn btn-primary" href="<?php echo e(route('admin.editautocode',$auto->id)); ?>"> <i class="fa fa-edit"></i> Update</a>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.adminlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wiconbd\resources\views/admin/autocode/autocodes.blade.php ENDPATH**/ ?>