
<?php $__env->startSection('content'); ?>
<h1 class="mt-4">Products</h1>
                        <ol class="breadcrumb mb-4">
                            <li class="breadcrumb-item"> <a href="<?php echo e(route('admin.products')); ?>"> Products</a></li>
                            <li class="breadcrumb-item active">Add Product</li>
                        </ol>
<div class="container">
        <div class="">
            <h2>Add Product</h2>
            <hr>
             <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.alert','data' => []]); ?>
<?php $component->withName('alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
        </div>
        <div class="" style="">
            <div class="col-xs-10">
                <form class="fluid" role="form" action="<?php echo e(route('admin.addproduct')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="form-group pb-4">
                        <label for="productname">Product Name</label>
                        <input class="form-control " type="text" id="productname" name="productname" placeholder="" >
                    </div>
                    <div class="form-group pb-4">
                        <label class="" for="description">Product Details</label>
                        <textarea class="form-control" name="description" id="description" cols="20" rows="10"></textarea>
                    </div>
                    <div class="form-group pb-4">
                        <label for="category">Category</label>
                        <select class="form-control" name="category" id="category">
                            <option value="" selected disabled>Select a Category</option>
                            <?php $__currentLoopData = $cats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($cat->catname); ?>"><?php echo e($cat->catname); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="form-group pb-4">
                        <label for="brand">Brand</label>
                        <select class="form-control" name="brand" id="brand">
                            <option value="" selected disabled>Select a Brand</option>
                            <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($brand->brandname); ?>"><?php echo e($brand->brandname); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="form-group pb-4">
                        <label for="price">Price</label>
                        <div class="input-group">
                            <span class="input-group-addon px-3 pt-1 border">&#2547</span>
                            <input class="form-control" type="number" id="price" name="price" placeholder="" >
                            <span class="input-group-addon px-2 pt-2 border" >.00</span>
                        </div>
                    </div>
                    <div class="form-group pb-4">
                        <label for="quantity">Quantity</label>
                        <input class="form-control " type="number" id="quantity" name="quantity" placeholder="" >
                    </div>
                    <button class="form-control btn btn-primary" type="submit">save</button>
                </form>
            </div>
        </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.adminlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wiconbd\resources\views/admin/product/newproduct.blade.php ENDPATH**/ ?>