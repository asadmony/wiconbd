<?php $__env->startSection('content'); ?>
    <!--  =================================
                Slider Part start
         ==================================  -->
    <?php if($sliders): ?>

    <section id="banner-part">
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12 ">
                <div class="banner-slider">
                    <?php
                        $bglo = 1;
                    ?>
                    <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        if ($bglo < 5) {
                            $bglo++;
                        }else {
                            $bglo = 1;
                        }
                    ?>
                    <div class="banner-<?php echo e($bglo); ?>">
                        <div class="overlay">
                            <div class="container">
                                <div class="row">
                                    <div class="col-lg-6 col-md-12">
                                        <div class="bnrtxt">
                                            <h2>ওয়াইকন</h2>
                                            <h1><?php echo e($slider->title); ?> </h1>
                                            <p><?php echo e($slider->details); ?> </p>
                                            <?php if($slider->button): ?>
                                            <a href="<?php echo e($slider->buttonlink); ?>"><?php echo e($slider->buttonname); ?></a>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="col-lg-6 col-md-12">
                                        <div class="bnrimg">
                                            <img src="<?php echo e(asset($slider->image)); ?>" alt="WPDK5A-1">
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>
            </div>
        </div>
    </section>
    <?php endif; ?>
    <!--  =================================
                Led-block Part start
          ==================================  -->
    <section id="led-block">
        <div class="container">
            <div class="row">
                <div class="col-lg-6">
                    <div class="led-img">
                        <img src="<?php echo e(asset('frontend/images/WP-(Primium)2.png')); ?>" alt="WP-(Primium)2" data-parallax='{"z": 150, "from scroll": 45, "duration": 50}'>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="led-text">
                        <h1 class="pdct-typ">WICON</h1>
                        <h3>PREMIUM LED</h3>
                        <p class="prct-dtl">Lorem ipsum dolor sit amet consectetur adipisicing elit. Praesentium autem quisquam beatae unde esse neque iste consectetur necessitatibus iure, magnam quod est nobis inventore ipsum corporis ut labore culpa quis?
                        </p>
                        <a href="<?php echo e(route('products')); ?>" class="more-btn">More Product</a>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- ================================
            Product Banner Part Start
         ================================ -->
    <section id="product-banner-part">
        <div class="container">
            <?php if($banners): ?>

            <div class="row product-banner-slider">
                <?php $__currentLoopData = $banners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $banner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-lg-12 col-md-12 col-sm-12 p-0">
                    <div class="product-banner">
                            <img src="<?php echo e(asset($banner->image)); ?>" />
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <?php endif; ?>
        </div>
    </section>

    <!--  =================================
                Fan-block Part start
         ==================================  -->

    <section id="fan-block">
        <div class="container">
            <div class="row">
                <div class="col-lg-6 col-sm-12">
                    <div class="fan-text">
                        <h1 class="pdct-typ">WICON</h1>
                        <h3>PREMIUM FAN</h3>
                        <p class="prct-dtl">
                            Lorem ipsum dolor sit amet consectetur adipisicing elit. Praesentium autem quisquam beatae unde esse neque iste consectetur necessitatibus iure, magnam quod est nobis inventore ipsum corporis ut labore culpa quis?
                        </p>
                        <a href="<?php echo e(route('products')); ?>" class="more-btn">More Product</a>
                    </div>
                </div>
                <div class="col-lg-6 col-sm-12">
                    <div class="fan-img">
                        <img src="<?php echo e(asset('frontend/images/Premium Fan.png')); ?>" alt="WP-(Primium)2" data-parallax='{"z": 180, "duration":10}'>
                    </div>
                </div>
            </div>
        </div>
    </section>

    </section>
    <!--  =================================
             Lastest-prdt Part start
          ==================================  -->
    <section id="spcl-product-part">
        <div class="container">
            <div class="row spcl-prdct-slider">
                <?php
                    $latest = App\Product::latest()->take(8)->get();
                ?>
                <?php $__currentLoopData = $latest; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-lg-6 col-md-6 col-sm-12">
                    <div class="special-product">
                        <div class="row">
                            <div class="col-lg-5 justify-content-middle">
                                <div class="product-img">
                                    <a class="venobox" data-gall="gallery01" href="<?php echo e(asset($item->images[0]->image)); ?>">
                                        <img src="<?php echo e(asset($item->images[0]->image)); ?>" alt="wicon-rechargeable-pink-large_Side">
                                    </a>
                                </div>
                            </div>
                            <div class="col-lg-7">
                                <div class="product-details">
                                    <a href="#">
                                        <h2 class="pdct-typ">WICON</h2>
                                    </a>
                                    <h4><?php echo e(Str::limit($item->productname, 40)); ?></h4>
                                    <p class="prct-dtl">
                                        <?php echo e(Str::limit($item->description, 100)); ?>

                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>

    <!--  =================================
              Freeze-block Part start
          ==================================  -->
    <section id="freeze-block">
        <div class="container">
            <div class="row">
                <div class="col-lg-6 col-sm-12">
                    <div class="freeze-img">
                        <img src="<?php echo e(asset('frontend/images/freeze.png')); ?>" alt="freeze">
                    </div>
                    <div class="freeze-img-2">
                        <img src="<?php echo e(asset('frontend/images/freeze.png')); ?>" alt="freeze">
                    </div>
                    <div class="freeze-img-3">
                        <img src="<?php echo e(asset('frontend/images/freeze.png')); ?>" alt="freeze">
                    </div>
                </div>
                <div class="col-lg-6 col-sm-12">
                    <div class="freeze-text">
                        <h2 class="pdct-typ">WICON</h2>
                        <h4>PREMIUM LED</h4>
                        <p class="prct-dtl">Lorem ipsum dolor sit amet consectetur adipisicing elit. Praesentium autem quisquam beatae unde esse neque iste consectetur necessitatibus iure, magnam quod est nobis inventore ipsum corporis ut labore culpa quis?
                        </p>
                        <ul class="colors-freze">
                            <li>
                                <a class="freeze-color" href="#">
                                    <img src="<?php echo e(asset('frontend/images/freeze-color-1.png')); ?>" alt="freeze-color-1">
                                </a>
                            </li>
                            <li>
                                <a class="freeze-color" href="#">
                                    <img src="<?php echo e(asset('frontend/images/freeze-color-2.png')); ?>" alt="freeze-color-2">
                                </a>
                            </li>
                            <li>
                                <a class="freeze-color" href="#">
                                    <img src="<?php echo e(asset('frontend/images/freeze-color-1.png')); ?>" alt="freeze-color-1">
                                </a>
                            </li>
                        </ul>
                        <a href="<?php echo e(route('products')); ?>" class="more-btn">More Product</a>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--  =================================
                 Video-content Part start
          ==================================  -->
    <section id="video-content">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-sm-12 p-0">
                    <div class="video-box">
                        <iframe id="youtubevideo" src="https://www.youtube-nocookie.com/embed/L_EOATyJwz0" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wiconbd\resources\views/index.blade.php ENDPATH**/ ?>