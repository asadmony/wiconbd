<?php $__env->startSection('content'); ?>


    <!--  =================================
                Products Part start
          ==================================  -->
    <section id="products-part">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="products-header">
                        <h3>Our Products</h3>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12">
                    <?php if($banners): ?>
                    <div class="prduct-banner">
                        <?php $__currentLoopData = $banners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $banner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="prdct-img-1">
                            <img src="<?php echo e(asset($banner->image)); ?>" alt="777">
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-6">
                    <div class="products-name-header">
                        <h3> <strong>Wicon</strong> Premium</h3>
                    </div>
                </div>
                <div class="col-lg-6">
                    
                </div>
                <div class="col-lg-12 col-sm-12">
                    <div class="products-prduct">
                        <div class="row">
                            <?php if($products): ?>
                                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-lg-4 col-md-6 col-sm-12 p-0">
                                        <div class="product-1" >
                                            <img src="<?php echo e(asset($product->images[0]->image)); ?>" alt="<?php echo e($product->productname); ?>">
                                            <div class="prdct-icon">
                                                <a href="<?php echo e(route('product', [$product->id, Str::slug($product->productname)])); ?>"><i class="far fa-heart"></i></a>
                                                <a href="<?php echo e(route('product', [$product->id, Str::slug($product->productname)])); ?>">
                                                    <i class="far fa-eye"></i>
                                                </a>
                                            </div>
                                            <div class="prdt-txt">
                                                <a href="<?php echo e(route('product', [$product->id, Str::slug($product->productname)])); ?>">
                                                    <h4><?php echo e(Str::limit($product->productname, 37)); ?></h4>
                                                </a>
                                                <p> <?php echo e(Str::limit($product->description, 60)); ?></p>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                <p>No product found.</p>
                            <?php endif; ?>
                        </div>
                        <?php echo e($products->links()); ?>

                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wiconbd\resources\views/products.blade.php ENDPATH**/ ?>