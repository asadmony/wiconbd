<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row mt-4 justify-content-center">
        <div class="col-md-10">
            <div class="card">
                <div class="card-header"><?php echo e(__('Dashboard')); ?></div>
                <?php
                    $productcount = App\Product::count();
                ?>
                <div class="card-body">
                    Total Products: <?php echo e($productcount); ?>

                </div>
                <?php
                    $categorycount = App\Category::count();
                ?>
                <div class="card-body">
                    Total Categories: <?php echo e($categorycount); ?>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.adminlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wiconbd\resources\views/home.blade.php ENDPATH**/ ?>