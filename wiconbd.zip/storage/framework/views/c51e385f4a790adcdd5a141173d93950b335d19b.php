<?php $__env->startSection('content'); ?>
    <h1 class="mt-4">Products</h1>
    <ol class="breadcrumb mb-4">
        <li class="breadcrumb-item">Products</li>
    </ol>
<div class="container-fluid">
        <div class="header">
            <h2>List of Products <a href="<?php echo e(route('admin.newproduct')); ?>"><i class="pe-7s-plus"></i></a></h2>
            <hr>
        </div>
        <div class="" style="">
             <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.alert','data' => []]); ?>
<?php $component->withName('alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
            <div class="col-xs-12">
                <div class="table-responsive">
                    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                        <thead>
                            <tr>
                                <th>Product Code</th>
                                <th>Product Name</th>
                                <th width="30%">Details</th>
                                <th width="15%">Features</th>
                                <th>Category</th>
                                <th>Brand</th>
                                <th width="8%">Price</th>
                                
                                <th width="3%">Option</th>
                            </tr>
                        </thead>
                        <tfoot>
                            <tr>
                                <th>Product Code</th>
                                <th>Product Name</th>
                                <th>Details</th>
                                <th>Features</th>
                                <th>Category</th>
                                <th>Brand</th>
                                <th>Price</th>
                                
                                <th>Option</th>
                            </tr>
                        </tfoot>
                        <tbody>
                            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($product->productcode); ?></td>
                                <td><?php echo e($product->productname); ?></td>
                                <td><?php echo e($product->description); ?></td>
                                <td class="">
                                    <?php $__currentLoopData = $product->features; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feature): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <ul class="list-inline py-0 my-0">
                                            <li class="list-inline-item">
                                                <a class="" style="color: red" href="" onclick="event.preventDefault();
                                if(confirm('Are you sure to delete this feature?')){
                                    document.getElementById('form-deletefeature-<?php echo e($feature->id); ?>')
                                    .submit()
                                }"> <i class="fa fa-times"></i></a>
                                <form style="display: none;" id="form-deletefeature-<?php echo e($feature->id); ?>" method="POST" action="<?php echo e(route('admin.deleteproductfeature', $feature->id)); ?>">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('delete'); ?>
                                </form>
                                            </li>
                                                    <li class="list-inline-item">
                                                       <i> <?php echo e($feature->featurename); ?> : </i>
                                                    </li>
                                                    <li class="list-inline-item">
                                                        <?php echo e($feature->featurevalue); ?>

                                                    </li>
                                                </ul>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <div class="text-center pt-1">
                                            <a class="btn btn-primary btn-sm" href="<?php echo e(route('admin.newproductfeature', $product->id)); ?>">add features</a>
                                        </div>
                                </td>
                                <td><?php echo e($product->category); ?></td>
                                <td><?php echo e($product->brand); ?></td>
                                <td> &#2547 <?php echo e($product->price); ?></td>
                                
                                <td>
                                    <div class=" text-center p-2">
                                        <a class="btn btn-info btn-sm" href="<?php echo e(route('admin.productimages',$product->id)); ?>"> <i class="pe-7s-photo"></i> Images</a>
                                    </div>
                                    <a class="nav-link dropdown-toggle" id="userDropdown" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i class="fas fa-cog fa-fw"></i> options </a>
                                    <div class="dropdown-menu dropdown-menu-right" aria-labelledby="userDropdown">
                                        
                                        <a class="dropdown-item" href="<?php echo e(route('admin.editproduct',$product->id)); ?>"><i class="fa fa-edit"></i> Edit</a>
                                        <a class="dropdown-item" href="" onclick="event.preventDefault();
                                        if(confirm('Are you sure to delete?')){
                                            document.getElementById('form-delete-<?php echo e($product->id); ?>')
                                            .submit()
                                        }"> <i class="fa fa-trash"></i> Delete</a>
                                        <form style="display: none;" id="form-delete-<?php echo e($product->id); ?>" method="POST" action="<?php echo e(route('admin.deleteproduct', $product->id)); ?>">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('delete'); ?>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
</div>
<div class="modal fade" id="discount" tabindex="-1">
    <!-- content will come from js function  -->
  </div>
  <script>
  function makediscount(id,price,code){
    var price = parseInt(price);
    var id = parseInt(id);
      var data = '<div class="modal-dialog">'+
    '<div class="modal-content">'+
      '<div class="modal-header">'+
        '<button class="close" data-dismiss="modal" type="button">×</button>'+
      '</div>'+
      '<div class="modal-body">'+
          '<div class="rows">'+
          '<h2>Discount for : '+code+'</h2>'+
          '</div>'+
          '<div class="rows">'+
            '<form action="/admin/product/'+id+'/setdiscount" method="POST">'+
            '<?php echo csrf_field(); ?>'+
            '<?php echo method_field("put"); ?>'+
        '<div class="form-group">'+
                '<lebel for="discount">Discount</lebel>'+
        '<div class="input-group">'+
                '<input class="form-control disper" type="number" onChange="calculate(this.value,'+price+')" id="discount" name="discount" value="0.0" step="any" min="0" max="100">'+
                '<span class="input-group-addon px-2 pt-1 border">'+
                    '<i>%</i>'+
                  '</span>'+
          '</div>'+
          '</div>'+
        '<div class="form-group">'+
                '<lebel for="discountprice">Price after Discount</lebel>'+
        '<div class="input-group">'+
                '<span class="input-group-addon px-3 pt-1 border">'+
                    '<i>&#2547</i>'+
                  '</span>'+
                '<input class="form-control disper" type="text" id="discountprice" name="discountprice" value="'+price+'" readonly="true">'+
          '</div>'+
          '</div>'+
          '<button class="form-control disper" type="submit">Save</button>'+
            '</form>'+
        '</div>'+
      '</div>'+
      '<div class="modal-footer">'+
        '<button class="btn btn-default" data-dismiss="modal" type="button">Close</button>'+
      '</div>'+
    '</div>'+
  '</div>';
      $("#discount").html(data);
      }
      function calculate(discount,price){
        if (discount > 0 && discount <101) {
        var dis = discount / 100;
        var disprice = price * dis;
        var discountprice = price - disprice;
        console.log(discountprice);
        document.getElementById("discountprice").value = parseInt(discountprice);
        }
      }
  </script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.adminlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wiconbd\resources\views/admin/product/products.blade.php ENDPATH**/ ?>