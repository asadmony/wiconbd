<?php $__env->startSection('content'); ?>
    <h1 class="mt-4">Banners</h1>
                        <ol class="breadcrumb mb-4">
                            <li class="breadcrumb-item"> <a href="<?php echo e(route('admin.sliders')); ?>">Banners</a></li>
                            <li class="breadcrumb-item active">Add Banner</li>
                        </ol>
<div class="container">
        <div class="header">
            <h2>Add Banner</h2>
            <hr>
        </div>
        <div class="" style="">
            <div class="col-xs-10">
                 <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.alert','data' => []]); ?>
<?php $component->withName('alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                <form class="fluid" role="form" action="<?php echo e(route('admin.newbanner')); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="form-group pb-4">
                        <label class="" for="image">Banner Image</label>
                        <input class="form-control" type="file" name="image" >
                    </div>
                    <div class="form-group pb-4">
                        <label for="link">Banner Link (optional)</label>
                        <input class="form-control " type="text" id="link" name="link" placeholder="http://example.com/element" >
                    </div>
                    <button class="form-control btn btn-primary" type="submit">save</button>
                </form>
            </div>
        </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.adminlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wiconbd\resources\views/admin/banner/newbanner.blade.php ENDPATH**/ ?>