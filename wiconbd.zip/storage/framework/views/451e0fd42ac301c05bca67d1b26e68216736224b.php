
<?php $__env->startSection('content'); ?>
    <h1 class="mt-4">Sliders</h1>
                        <ol class="breadcrumb mb-4">
                            <li class="breadcrumb-item">Sliders</li>
                        </ol>
<div class="container">
        <div class="header">
            <h2>List of Sliders <a href="<?php echo e(route('admin.newslider')); ?>"><i class="pe-7s-plus"></i></a></h2>
            <hr>
        </div>
        <div class="" style="">
             <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.alert','data' => []]); ?>
<?php $component->withName('alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
            <div class="col-xs-10">
                <div class="table-responsive">
                    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                        <thead>
                            <tr>
                                <th>Image</th>
                                <th>Title</th>
                                <th>Details</th>
                                <th>Button</th>
                                <th>Button Name</th>
                                <th>Button Link</th>
                                <th>Option</th>
                            </tr>
                        </thead>
                        <tfoot>
                            <tr>
                                <th>Image</th>
                                <th>Title</th>
                                <th>Details</th>
                                <th>Button</th>
                                <th>Button Name</th>
                                <th>Button Link</th>
                                <th>Option</th>
                            </tr>
                        </tfoot>
                        <tbody>
                            <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="text-center">
                                    <img class="img rounded" src="<?php echo e(asset($slider->image)); ?>" alt="<?php echo e($slider->title); ?>" style="max-width: 160px">
                                </td>
                                <td><?php echo e($slider->title); ?></td>
                                <td><?php echo e($slider->details); ?></td>
                                <td>
                                    <div>
                                        <slider-button button="<?php echo e($slider->button); ?>" slider="<?php echo e($slider->id); ?>"></slider-button>
                                    </div>
                                </td>
                                <td><?php echo e($slider->buttonname); ?></td>
                                <td><?php echo e($slider->buttonlink); ?></td>
                                <td>
                                    <div class="p-2">
                                        <a class="btn btn-primary" href="<?php echo e(route('admin.editslider',$slider->id)); ?>"> <i class="fa fa-edit"></i> Edit</a>
                                    </div>
                                    <div class="p-2">
                                        <a class="btn btn-danger " href="" onclick="event.preventDefault();
                                        if(confirm('Are you sure to delete?')){
                                            document.getElementById('form-delete-<?php echo e($slider->id); ?>')
                                            .submit()
                                        }"> <i class="fa fa-trash"></i> Delete</a>
                                        <form style="display: none;" id="form-delete-<?php echo e($slider->id); ?>" method="POST" action="<?php echo e(route('admin.deleteslider', $slider->id)); ?>">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('delete'); ?>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.adminlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wiconbd\resources\views/admin/slider/sliders.blade.php ENDPATH**/ ?>