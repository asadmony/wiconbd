

<?php $__env->startSection('content'); ?>
<h1 class="mt-4">Features</h1>
                        <ol class="breadcrumb mb-4">
                            <li class="breadcrumb-item"> <a href="<?php echo e(route('admin.products')); ?>"> Products</a></li>
                            <li class="breadcrumb-item active"><?php echo e($product->productcode); ?></li>
                            <li class="breadcrumb-item active">Features</li>
                        </ol>
<div class="container">
        <div class="">
            <h2>Add Features</h2>
            <hr>
             <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.alert','data' => []]); ?>
<?php $component->withName('alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
        </div>

        <div class="container pt-3">
            <form action="<?php echo e(route('admin.addproductfeature', $product->id)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <div class="input-group">
                        <label class="pr-1" for="featurename-1">Feature name 1: </label>
                        <input class="form-control" type="text" id="featurename-1" name="featurename-1" placeholder="ex.: Model">
                    </div>
                    <div class="input-group pt-2">
                        <label class="pr-1" for="featurevalue-1">Feature value 1: </label>
                        <textarea class="form-control" type="text" id="featurevalue-1" name="featurevalue-1" placeholder="ex.: Galaxy S10"></textarea>
                    </div>
                    <hr>
                </div>
                <div id="morefield" class="form-group">
                    
                </div>
                <div id="totfield" class="form-group">
                    <input type="hidden" name="totinput" value="1">
                </div>
                <div class="form-group">
                    <a class="btn border" href="" onclick="event.preventDefault();addfield()">+ add more feature field</a>
                </div>
                <div class="form-group">
                    <button class="btn form-control btn-primary" type="submit">Save</button>
                </div>
            </form>
        </div>
    </div>
    <script>
        var i = 1;
        console.log('ok');
        function addfield(){
            i++;
            var data = '<div class="form-group">'+
                    '<div class="input-group">'+
                    '<label class="pr-1" for="featurename-'+i+'">Feature name '+i+': </label>'+
                        '<input class="form-control" type="text" id="featurename-'+i+'" name="featurename-'+i+'">'+
                    '</div>'+
                    '<div class="input-group pt-2">'+
                    '<label class="pr-1" for="featurevalue-'+i+'">Feature value '+i+': </label>'+
                        '<textarea class="form-control" type="text" id="featurevalue-'+i+'" name="featurevalue-'+i+'"></textarea>'+
                    '</div>'+
                    '<hr>'+
                '</div>';
        $("#morefield").append(data);
        var tot = '<input type="hidden" name="totinput" value="'+i+'">';
        $("#totfield").html(tot);
        }
        </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.adminlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wiconbd\resources\views/admin/product/newfeature.blade.php ENDPATH**/ ?>